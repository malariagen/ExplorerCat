/**
 * Namespace that contains the libraries for the development of front-end
 * plugins.
 * @namespace
 */

expcat.plugins = {}