expcat.namespace("expcat.cql.condition");

/**
 * Namespace that contains all the utilities related to the creation of CQL
 * queries.
 * @namespace
 */

expcat.cql = {}