
echo "" > ../lib/expcat-explorer-debug.js

cat expcat.cql.Type.js >> ../lib/expcat-explorer-debug.js
cat expcat.cql.Operator.js >> ../lib/expcat-explorer-debug.js
cat expcat.cql.Value.js >> ../lib/expcat-explorer-debug.js
cat expcat.cql.Property.js >> ../lib/expcat-explorer-debug.js
cat expcat.cql.Clause.js >> ../lib/expcat-explorer-debug.js
cat expcat.plugins.ConditionBar.js >> ../lib/expcat-explorer-debug.js
cat expcat.plugins.OperatorBar.js >> ../lib/expcat-explorer-debug.js
cat expcat.plugins.QueryComposerUI.js >> ../lib/expcat-explorer-debug.js
cat expcat.plugins.QueryComposerUIManager.js >> ../lib/expcat-explorer-debug.js

cat expcat.plugins.RGB.js >> ../lib/expcat-explorer-debug.js
cat expcat.plugins.RGB.Gradient.js >> ../lib/expcat-explorer-debug.js

cat expcat.plugins.TableCellRenderer.js >> ../lib/expcat-explorer-debug.js

cat expcat.plugins.DataTable.js >> ../lib/expcat-explorer-debug.js

cat expcat.plugins.TextFileExporter.js >> ../lib/expcat-explorer-debug.js
