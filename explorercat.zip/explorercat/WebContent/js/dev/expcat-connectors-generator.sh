
echo "" > ../lib/expcat-connectors.js

cat expcat.js >> ../lib/expcat-connectors.js
cat expcat.cql.js >> ../lib/expcat-connectors.js
cat expcat.cql.CQLConnector.js >> ../lib/expcat-connectors.js
cat expcat.cql.UtilConnector.js >> ../lib/expcat-connectors.js








