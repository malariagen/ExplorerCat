package net.explorercat.compactcat.parser.json;

public interface DictrionaryParser {

}
