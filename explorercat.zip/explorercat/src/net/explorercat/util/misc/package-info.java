/**
 * Collection of utility classes that are used in the EC system. They just make
 * life easier. Notice that some of them will be replaced or removed from the
 * codebase after the next refactoring iteration.
 * 
 * @author Jacob Almagro-Garcia
 */

package net.explorercat.util.misc;