/**
 * Classes that provide secure connections to SQL data sources.
 * 
 * @author Jacob Almagro-Garcia
 */

package net.explorercat.util.sql.dataconnectors;